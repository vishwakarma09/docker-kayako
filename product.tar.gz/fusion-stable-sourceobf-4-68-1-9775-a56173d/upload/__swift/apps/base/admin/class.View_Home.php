<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The Dashboard View
 *
 * @author Varun Shoor
 */
class View_Home extends SWIFT_View
{
	private $_infoClass = '2';

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __construct()
	{
		parent::__construct();

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		parent::__destruct();

		return true;
	}

	/**
	 * Render the Error HTML
	 *
	 * @author Varun Shoor
	 * @param string $_title The Box Title
	 * @param string $_contents The Box Contents
	 * @param string $_date The Date Row Data
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderError($_title, $_contents, $_date = '', $_escape = true)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (empty($_title) || empty($_contents)) {
			return false;
		}

		$_finalContents = $_contents;
		if ($_escape)
		{
			$_finalContents = nl2br(htmlspecialchars($_contents));
		}

		return '<div class="dashboardboxerror"><div class="dashboardboxtitlecontainer"><div class="dashboardboxtitle">' . $_title . '</div><div class="dashboardboxdate">' . $_date . '</div></div>' . $_finalContents . '</div>';
	}

	/**
	 * Render the Alert HTML
	 *
	 * @author Varun Shoor
	 * @param string $_title The Box Title
	 * @param string $_contents The Box Contents
	 * @param string $_date The Date Row Data
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderAlert($_title, $_contents, $_date = '')
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (empty($_title) || empty($_contents)) {
			return false;
		}

		return '<div class="dashboardboxalert"><div class="dashboardboxtitlecontainer"><div class="dashboardboxtitle">' . $_title . '</div><div class="dashboardboxdate">' . $_date . '</div></div>' . $_contents . '</div>';
	}

	/**
	 * Renders the Info HTML
	 *
	 * @author Varun Shoor
	 * @param string $_title The Box Title
	 * @param string $_contents The Box Contents
	 * @param string $_date The Date Row Data
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderInfo($_title, $_contents, $_date = '')
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (empty($_title) || empty($_contents)) {
			return false;
		}

		if ($this->_infoClass == '1')
		{
			$this->_infoClass = '2';
		} else {
			$this->_infoClass = '1';
		}

		return '<div class="dashboardboxinfo' . $this->_infoClass . '"><div class="dashboardboxtitlecontainer"><div class="dashboardboxtitle">' . $_title . '</div><div class="dashboardboxdate">' . $_date . '</div></div>' . $_contents . '</div>';
	}

	/**
	 * Renders the Dashboard
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderDashboard()
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_staffLastVisit = $_SWIFT->Staff->GetProperty('lastvisit');
		if (empty($_staffLastVisit))
		{
			$_lastVisit = $this->Language->Get('never');
		} else {
			$_lastVisit = SWIFT_Date::Get(SWIFT_Date::TYPE_DATETIME, $_SWIFT->Staff->GetProperty('lastvisit')) . ' (' . SWIFT_Date::ColorTime(DATENOW-$_SWIFT->Staff->GetProperty('lastvisit'), false, true) . ')';
		}

		echo '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="dashboardlayoutborder" style="margin-top: 0;">
		<tr>
		<td align="left" valign="bottom" id="dashboardcontainer">
		<div id="dashboardtitle">'. $this->Language->Get('dashdashboard') . '</div>
		</td>
		</tr>
		<tr><td align="left" valign="top">

		<div style="PADDING: 8px;">

		<!-- BEGIN FIRST ROW (DATE, USERDETAILS) -->
		<table width="100%" border="0" cellspacing="1" cellpadding="0">
		<tr>
		<td align="left" valign="top" width="">

		<div style="display: inline-block; float: right;">';

//		echo $this->RenderCounters($_counterContainer);

		echo '</div>

			<div style="float: left; padding-left: 8px;">
			<table width="100%" border="0" cellspacing="1" cellpadding="0">
			<tr>
			<td align="left" valign="middle" width="80">
			<div class="dashboardavatarimage">
			<img src="' . SWIFT::Get('basename') . '/Base/StaffProfile/DisplayAvatar/' . $_SWIFT->Staff->GetStaffID() . '/' . md5($_SWIFT->Staff->GetProperty('email')) . '/80/0" align="absmiddle" />
			</div>
			</td>
			<td align="left" valign="top" width=""><div class="dashboardrightcontents"><div class="dashboardusername">' . htmlspecialchars($_SWIFT->Staff->GetProperty('fullname')) . '</div>
			<div class="smalltext">' . $this->Language->Get('dashusername') . ' ' . htmlspecialchars($_SWIFT->Staff->GetProperty('username')) . '<br />
			' . $this->Language->Get('dashemail') . ' ' . htmlspecialchars($_SWIFT->Staff->GetProperty('email')) . '<br />
			' . $this->Language->Get('dashlastlogin') . ' ' . $_lastVisit . '<br /></div></div>
			</td>
			</tr>
			</table>
			</div>
		</td>
		<td align="left" valign="top" width="250">

		<div style="float: right;">
		<table width="100%" border="0" cellspacing="1" cellpadding="0">
		<tr>
		<td align="left" valign="top" width="80">
			<div class="dashboarddate">
				<div class="dashboarddatecontainer">
				<div class="dashboardmonthholder"><div class="dashboardmonthsub">' . SWIFT_Date::Get(SWIFT_Date::TYPE_CUSTOM, false, '%b') .'</div></div>
				<div class="dashboarddateholder"><div class="dashboarddatesub">' . SWIFT_Date::Get(SWIFT_Date::TYPE_CUSTOM, false, '%A') . '</div><div class="dashboarddatedcontainer">' . SWIFT_Date::Get(SWIFT_Date::TYPE_CUSTOM, false, '%d') . '</div></div>
				</div>
			</div>
		</td>
		</tr></table>
		</div>

		</td>
		</tr></table>
		<!-- END FIRST ROW -->


		<!-- BEGIN SECOND ROW -->
		<table width="100%" border="0" cellspacing="1" cellpadding="4">
		<tr>
		<td align="left" valign="top" width="">
		<div id="dashboardtabs"><ul>';

		$_tabContainer = $this->Controller->_GetTabContainer();

		$_tabHTML = '';
		if (_is_array($_tabContainer))
		{
			foreach ($_tabContainer as $_key => $_val)
			{
				echo '<li>' . IIF(!empty($_val[Controller_Home::TAB_COUNTER]), '<div class="notecounterredver">' . $_val[Controller_Home::TAB_COUNTER] . '</div>') . '<a href="#dashboardtabs-' . $_val[Controller_Home::TAB_NAME] . '"><img src="' . SWIFT::Get('themepath') . 'images/' . $_val[Controller_Home::TAB_ICON] . '' . '" align="absmiddle" border="0" /> ' . $_val[Controller_Home::TAB_TITLE] . '</a></li>';

				$_tabHTML .= '<div id="dashboardtabs-' . $_val[Controller_Home::TAB_NAME] . '"><div class="ui-tabs-vertical-custom-prop"></div>';

				$_tabHTML .= $_val[Controller_Home::TAB_CONTENTS];

				$_tabHTML .= '<div class="ui-tabs-vertical-custom-clear"></div></div>';
			}
		}

		echo '</ul>';

		echo $_tabHTML;

		echo '</div>
		</td>';


		/**
		 * ---------------------------------------------
		 * LICENSE DETAILS
		 * ---------------------------------------------
		 */
		$_domainList = array();

		$_notAvailable = $this->Language->Get('na');

		$_licenseExpiry = $_licenseFullName = $_licenseUniqueID = $_licenseStaff = $_licenseOrganization = $_notAvailable;

		if (SWIFT::Get('licenseexpiry') !== false && SWIFT::Get('licenseexpiry') > 100)
		{
			$_licenseExpiry = SWIFT_Date::Get(SWIFT_Date::TYPE_DATE, SWIFT::Get('licenseexpiry'));
		} else {
			$_licenseExpiry = $this->Language->Get('licexpirenever');
		}

		if (SWIFT::Get('licensefullname') !== false)
		{
			$_licenseFullName = htmlspecialchars(SWIFT::Get('licensefullname'));
		}

		if (SWIFT::Get('licenseorganization') !== false)
		{
			$_licenseOrganization = htmlspecialchars(SWIFT::Get('licenseorganization'));
		}

		if (SWIFT::Get('licenseuniqueid') !== false)
		{
			$_licenseUniqueID = htmlspecialchars(SWIFT::Get('licenseuniqueid'));
		}

		if (SWIFT::Get('licensestaff') !== false)
		{
			if (SWIFT::Get('licensestaff') == '0')
			{
				$_licenseStaff = $this->Language->Get('licunlimited');
			} else {
				$_licenseStaff = htmlspecialchars(SWIFT::Get('licensestaff'));
			}
		}

		if (SWIFT::Get('licensedomains') !== false)
		{
			$_domainList = SWIFT::Get('licensedomains');
		}

		echo '<td align="left" valign="top" width="200">';

		/*
		 * ##########################################################################
		 * Live chat tag for trial licenses
		 * ##########################################################################
		 */
		if (SWIFT::Get('licenseistrial') == 1) {
			echo '<div class="kayakochatbuttoncontainer">
				<table align="center">
					<tr>
						<td align="center" valign="middle">
							' . $this->Language->Get('chatwithkayako') . '
						</td>
						<td>
							<!-- BEGIN TAG CODE - DO NOT EDIT! --><div><div id="proactivechatcontainer83acjjnu4e"></div><table border="0" cellspacing="2" cellpadding="2"><tr><td align="center" id="swifttagcontainer83acjjnu4e"><div style="display: inline;" id="swifttagdatacontainer83acjjnu4e"></div><a target="_blank" href="https://support.kayako.com/visitor/index.php?/default/LiveChat/Chat/Request/_sessionID=/_promptType=chat/_proactive=0/_filterDepartmentID=/_randomNumber=nlz6vk15winiik35co8j1k51i4x48k6y/_fullName=/_email=/" class="livechatlink"><img src="https://support.kayako.com/visitor/index.php?/default/LiveChat/HTML/NoJSImage/cHJvbXB0dHlwZT1jaGF0JnVuaXF1ZWlkPTgzYWNqam51NGUmdmVyc2lvbj00LjY3LjAmcHJvZHVjdD1GdXNpb24mY3VzdG9tb25saW5lPSZjdXN0b21vZmZsaW5lPSZjdXN0b21hd2F5PSZjdXN0b21iYWNrc2hvcnRseT0KM2FmMjM4OGZmMDE5OWU4ZjA4MzQ1OTM2MWZjNWI0ODk5ZWE0NzZkZg==" align="absmiddle" border="0" /></a></td> </tr></table></div><!-- END TAG CODE - DO NOT EDIT! -->
						</td>
					</tr>
				</table>
			</div>';
		}

		echo '<div class="tabparent">
	<ul class="tab">
		<li>
			<a href="javascript:void(0);" class="currenttab">
			<span>
			<div style="height: 16px; float: left;">' . $this->Language->Get('licensedetails') . '</div>
			</span>
			</a>
		</li>
	</ul>
<div class="basictabcontent">
<table cellspacing="0" cellpadding="4" border="0">
<tbody>
<tr>
<td class="gridrow1" width="40%" valign="top" align="left">' . $this->Language->Get('dproduct') .'</td>
<td class="gridrow2" width="60%" valign="top" align="left">' . SWIFT_PRODUCT . '</td>
</tr>
<tr>
<td class="gridrow1" width="40%" valign="top" align="left">' . $this->Language->Get('licversion') . '</td>
<td class="gridrow2" width="60%" valign="top" align="left">' . SWIFT_VERSION . '</td>
</tr>
<tr>
<td class="gridrow1" width="40%" valign="top" align="left">' . $this->Language->Get('licowner') . ':</td>
<td class="gridrow2" width="60%" valign="top" align="left">' . $_licenseFullName . '</td>
</tr>
<tr>
<td class="gridrow1" width="40%" valign="top" align="left">' . $this->Language->Get('licorganization') . ':</td>
<td class="gridrow2" width="60%" valign="top" align="left">' . $_licenseOrganization . '</td>
</tr>
<tr>
<td class="gridrow1" width="40%" valign="top" align="left">' . $this->Language->Get('licexpires') . ':</td>
<td class="gridrow2" width="60%" valign="top" align="left">' . $_licenseExpiry . '</td>
</tr>
<tr>
<td class="gridrow1" width="40%" valign="top" align="left">' . $this->Language->Get('licstaff') . ':</td>
<td class="gridrow2" width="60%" valign="top" align="left">' . $_licenseStaff . '</td>
</tr>
<tr>
<td class="gridrow1" width="40%" valign="top" align="left">' . $this->Language->Get('licdomains') . ':</td>
<td class="gridrow2" width="60%" valign="top" align="left">' . implode('<br />', $_domainList) . '</td>
</tr>
</tbody>
</table>
</div></div>';


		/*
		 * ###############################################
		 * BEGIN NEWS PROCESSING
		 * ###############################################
		 */
		 $_newsContainer = $this->Controller->_GetKayakoNews();

		echo '<div class="navbox">
	<div class="navboxtop">
		<div class="navboxtopleft">&nbsp;</div>
		<div style="padding-top: 4px;"><!--<img src="' . SWIFT::Get('themepath') . 'images/' . 'doublearrowsnav.gif" border="0" align="absmiddle" />--> ' . $this->Language->Get('latestkayakonews') . '</div>
	</div>
<div class="navboxcontent">';

		$_navClass = 'navitem';
		foreach ($_newsContainer as $_key => $_val)
		{
			if ($_navClass == 'navitem')
			{
				$_navClass = 'navitem2';
			} else {
				$_navClass = 'navitem';
			}

			$_iconSuffix = '';
			if (!empty($_staffLastVisit) && $_val[2] > $_staffLastVisit)
			{
				$_iconSuffix = ' <img src="' . SWIFT::Get('themepath') . 'images/icon_new.gif' . '" align="absmiddle" border="0" />';
			}

			echo '<div class="' . $_navClass . '" onmouseover="javascript:this.className=\'navitemhover\';" onmouseout="javascript:this.className=\'' . $_navClass . '\';"><!--<img src="' . SWIFT::Get('themepath') . 'images/icon_news.gif" align="absmiddle" border="0" />&nbsp;--><a href="' . htmlspecialchars($_val[1]) . '" target="_blank">' . SWIFT_Date::Get(SWIFT_DATE::TYPE_DATEFULL, $_val[2]) . ': ' . htmlspecialchars($_val[0]) . $_iconSuffix . '</a></div>';
		}

		echo '</div></div>';

		/*
		 * ###############################################
		 * END NEWS PROCESSING
		 * ###############################################
		 */

		echo '
		</td>
		</tr>
		</table>
		<!-- END SECOND ROW -->

		<script type="text/javascript">
		QueueFunction(function() {
			$("#dashboardtabs").tabs().addClass(\'ui-tabs-vertical ui-helper-clearfix\').removeClass(\'ui-corner-all ui-widget-content\');
			$("#dashboardtabs li").removeClass(\'ui-corner-top\').addClass(\'ui-corner-left\');
		});

		$(function() {
			ClearFunctionQueue();
		});
		</script>

		</div></td></tr></table>
		<div id="klic"></div>
		';
	}

	/**
	 * Render the Recent Activity Tab
	 *
	 * @author Varun Shoor
	 * @param array $_activityContainer The Activity Container
	 * @return string The Tab Contents
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderRecentActivityTab($_activityContainer)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_showingSuffix = '';
		if (count($_activityContainer[1]))
		{
			$_showingSuffix = sprintf($this->Language->Get('showingmsg'), count($_activityContainer[1]), $_activityContainer[0]);
		}

		$_tabContents = '<div>';

		$_tabContents .= $this->RenderTabHeader($this->Language->Get('tabrecentactivity') . $_showingSuffix, '/Base/ActivityLog/Manage');

		$_tabContents .= '<div class="dashboardtabdatacontainer">';

		if (!_is_array($_activityContainer[1]))
		{
			$_tabContents .= '<div class="dashboardmsg">' . $this->Language->Get('noinfoinview') . '</div>';
		} else {
			foreach ($_activityContainer[1] as $_val)
			{
				$_tabContents .= $this->RenderInfo($_val['title'], $_val['contents'], $_val['date']);
			}
		}

		$_tabContents .= '</div>';
		$_tabContents .= '</div>';

		return $_tabContents;
	}

	/**
	 * Render the Login Failure Tab
	 *
	 * @author Varun Shoor
	 * @param array $_failureContainer The Login Failure Container
	 * @return string The Tab Contents
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderLoginFailureTab($_failureContainer)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_showingSuffix = '';
		if (count($_failureContainer[1]))
		{
			$_showingSuffix = sprintf($this->Language->Get('showingmsg'), count($_failureContainer[1]), $_failureContainer[0]);
		}

		$_tabContents = '<div>';

		$_tabContents .= $this->RenderTabHeader($this->Language->Get('tabloginfailures') . $_showingSuffix, '/Base/LoginLog/Manage');

		$_tabContents .= '<div class="dashboardtabdatacontainer">';

		if (!_is_array($_failureContainer[1]))
		{
			$_tabContents .= '<div class="dashboardmsg">' . $this->Language->Get('noinfoinview') . '</div>';
		} else {
			foreach ($_failureContainer[1] as $_key => $_val)
			{
				$_tabContents .= $this->RenderError($_val['title'], $_val['contents'], $_val['date'], false);
			}
		}

		$_tabContents .= '</div>';
		$_tabContents .= '</div>';

		return $_tabContents;
	}

	/**
	 * Render the Error Log Tab
	 *
	 * @author Varun Shoor
	 * @param array $_errorContainer The Error Container
	 * @return string The Tab Contents
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderErrorLogTab($_errorContainer)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_showingSuffix = '';
		if (count($_errorContainer[1]))
		{
			$_showingSuffix = sprintf($this->Language->Get('showingmsg'), count($_errorContainer[1]), $_errorContainer[0]);
		}

		$_tabContents = '<div>';

		$_tabContents .= $this->RenderTabHeader($this->Language->Get('taberrorlog') . $_showingSuffix, '/Base/ErrorLog/Manage');

		$_tabContents .= '<div class="dashboardtabdatacontainer">';

		if (!_is_array($_errorContainer[1]))
		{
			$_tabContents .= '<div class="dashboardmsg">' . $this->Language->Get('noinfoinview') . '</div>';
		} else {
			foreach ($_errorContainer[1] as $_key => $_val)
			{
				$_tabContents .= $this->RenderError($_val['title'], $_val['contents'], $_val['date']);
			}
		}

		$_tabContents .= '</div>';
		$_tabContents .= '</div>';

		return $_tabContents;
	}

	/**
	 * Render the Parser Log Tab
	 *
	 * @author Varun Shoor
	 * @param array $_parserLogContainer The Parser Log Container
	 * @return string The Tab Contents
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderParserLogTab($_parserLogContainer)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_showingSuffix = '';
		if (count($_parserLogContainer[1]))
		{
			$_showingSuffix = sprintf($this->Language->Get('showingmsg'), count($_parserLogContainer[1]), $_parserLogContainer[0]);
		}

		$_tabContents = '<div>';

		$_tabContents .= $this->RenderTabHeader($this->Language->Get('tabparserlog') . $_showingSuffix, '/Parser/ParserLog/Manage');

		$_tabContents .= '<div class="dashboardtabdatacontainer">';

		if (!_is_array($_parserLogContainer[1]))
		{
			$_tabContents .= '<div class="dashboardmsg">' . $this->Language->Get('noinfoinview') . '</div>';
		} else {
			foreach ($_parserLogContainer[1] as $_key => $_val)
			{
				$_tabContents .= $this->RenderError($_val['title'], $_val['contents'], $_val['date'], false);
			}
		}

		$_tabContents .= '</div>';
		$_tabContents .= '</div>';

		return $_tabContents;
	}

	/**
	 * Render the Tab Header
	 *
	 * @author Varun Shoor
	 * @param string $_headerTitle The Header Title
	 * @param string $_extendedLink (OPTIONAL) The Extended Link to View More Info
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderTabHeader($_headerTitle, $_extendedLink = false)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_renderHTML = '<div>';

		if (!empty($_extendedLink))
		{
			$_renderHTML .= '<div style="float: right;"><div class="viewmore" onclick="javascript: loadViewportData(\'' . $_extendedLink . '\');"></div></div>';
		}
		$_renderHTML .= '<table class="hlineheaderext"><tr><th rowspan="2" nowrap>' . $_headerTitle . '</th><td>&nbsp;</td></tr><tr><td class="hlinelower">&nbsp;</td></tr></table>';
		$_renderHTML .= '</div>';

		return $_renderHTML;
	}

	/**
	 * Render Counters
	 *
	 * @author Varun Shoor
	 * @param array $_counterContainer The Counter Container
	 * @return string The Rendered HTML
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function RenderCounters($_counterContainer)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_renderHTML = '';

		foreach ($_counterContainers as $_counter) {
			if (empty($_counter[1]))
			{
				continue;
			}

			$_renderHTML .= '
			<div class="dashboardcounter" onclick="javascript: loadViewportData(\'' . $_counter[2] . '\');">
				<div class="dashboardcounterparent">
					<div class="dashboardcounterheader">' . $_counter[0] . '</div>
					<div class="dashboardcounternumber">' . $_counter[1] . '</div>
				</div>
			</div>
			';
		}

		return $_renderHTML;
	}
}
?>