<?php
                    /**
                    * ###############################################
                    *
                    * SWIFT Framework
                    * _______________________________________________
                    *
                    * @package        SWIFT
                    * @copyright    Copyright (c) 2001-2014, Kayako
                    * @license        http://www.kayako.com/license
                    * @link        http://www.kayako.com
                    *
                    * ###############################################
                    */

                       class Controller_Staff extends Controller_client {  public function __construct() { parent::__construct(); return true; }  public function __destruct() { parent::__destruct(); return true; }  public function GetProfileImage($_staffID) { HeaderNoCache(); if (!$this->GetIsClassLoaded()) { throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED); return false; } else if (empty($_staffID)) { $this->_DisplayEmptyImage(); return false; } $_SWIFT_StaffObject = new SWIFT_Staff(new SWIFT_DataID($_staffID)); if (!$_SWIFT_StaffObject instanceof SWIFT_Staff || !$_SWIFT_StaffObject->GetIsClassLoaded()) { $this->_DisplayEmptyImage(); return false; } $_SWIFT_StaffProfileImageObject = SWIFT_StaffProfileImage::RetrieveOnStaff($_SWIFT_StaffObject->GetStaffID()); if (!$_SWIFT_StaffProfileImageObject instanceof SWIFT_StaffProfileImage || !$_SWIFT_StaffProfileImageObject->GetIsClassLoaded()) { $this->_DisplayEmptyImage(); return false; } $_SWIFT_StaffProfileImageObject->Output(); return true; }  protected function _DisplayEmptyImage() { if (!$this->GetIsClassLoaded()) { throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED); return false; } header('Content-Type: image/gif'); echo base64_decode('R0lGODlhAQABAIAAAP//////zCH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=='); return true; }  public function GetCount() { $staff = $this->Database->QueryFetch("SELECT COUNT(1) AS total FROM " . TABLE_PREFIX . SWIFT_Staff::TABLE_NAME . " WHERE isenabled = 1"); $result = ['activestaffcount' => $staff['total']]; echo json_encode($result); } } ?>