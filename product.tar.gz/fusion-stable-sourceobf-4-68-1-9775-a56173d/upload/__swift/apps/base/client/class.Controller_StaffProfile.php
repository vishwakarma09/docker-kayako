<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The Staff related functions
 *
 * @author Varun Shoor
 */
class Controller_StaffProfile extends Controller_client
{
	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __construct()
	{
		parent::__construct();

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		parent::__destruct();

		return true;
	}

	/**
	 * Display the Avatar
	 *
	 * @author Varun Shoor
	 * @param int $_staffID The Staff ID
	 * @param string $_emailAddressHash (OPTIONAL) The Email Address Hash
	 * @param int $_preferredWidth (OPTIONAL) The Preferred Width
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function DisplayAvatar($_staffID = '', $_emailAddressHash = '', $_preferredWidth = 60)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		/* BUG FIX : Parminder Singh
		 *
		 * SWIFT-3238  Uncaught Exception: Invalid data provided in ./__swift/library/Image/class.SWIFT_ImageResize.php:371
		 *
		 * Comments : None
		 */

		$_preferredWidth = intval($_preferredWidth);
		if (empty($_preferredWidth)) {
			$_preferredWidth = 60;
		}

		SWIFT_ProfileImage::OutputOnStaffID($_staffID, $_emailAddressHash, $_preferredWidth);

		return true;
	}
}
?>