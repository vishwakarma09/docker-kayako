SWIFT.Models.TopMenu = SWIFT.Library.Model.extend({
	
});