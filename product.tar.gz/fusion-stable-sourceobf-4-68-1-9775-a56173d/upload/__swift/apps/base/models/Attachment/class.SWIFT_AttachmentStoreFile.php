<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The File Attachment Store
 *
 * @author Varun Shoor
 */
class SWIFT_AttachmentStoreFile extends SWIFT_AttachmentStore
{
	private $_filePath = '';
	private $_fileResource = false;

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @param string $_filePath The File Path
	 * @param string $_fileType The File Type
	 * @param string $_fileNameOpt (OPTIONAL) The Custom File Name
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If Invalid Data is Provided
	 */
	public function __construct($_filePath, $_fileType, $_fileNameOpt = '')
	{
		if (!file_exists($_filePath))
		{
			throw new SWIFT_Attachment_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_fileSize = filesize($_filePath);

		$_fileName = $_fileNameOpt;
		if (empty($_fileNameOpt)) {
			$_pathInfoContainer = pathinfo($_filePath);
			if (!isset($_pathInfoContainer['basename']) || empty($_pathInfoContainer['basename']))
			{
				throw new SWIFT_Attachment_Exception(SWIFT_INVALIDDATA);

				return false;
			}

			$_fileName = $_pathInfoContainer['basename'];
		}

		parent::__construct($_fileName, $_fileSize, $_fileType);

		$this->SetFilePath($_filePath);

		/**
		 * Open the File
		 */

		$this->OpenFile();

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		$this->CloseFile();

		parent::__destruct();

		return true;
	}

	/**
	 * Open the File and Set the File Resource
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded or If Invalid Data Provided
	 */
	protected function OpenFile()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		// Add the chunks
		$_filePointer = fopen($this->GetFilePath(), 'rb');
		if (!$_filePointer)
		{
			throw new SWIFT_Attachment_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$this->SetFileResource($_filePointer);

		return true;
	}

	/**
	 * Close the File Resource
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	protected function CloseFile()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_fileResource = $this->GetFileResource();
		if (!$_fileResource)
		{
			throw new SWIFT_Attachment_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		fclose($_fileResource);

		return true;
	}

	/**
	 * Set the File Resource
	 *
	 * @author Varun Shoor
	 * @param resource $_fileResource The File Resource
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded or If Invalid Data Provided
	 */
	protected function SetFileResource($_fileResource)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (!$_fileResource) {
			throw new SWIFT_Attachment_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$this->_fileResource = $_fileResource;

		return true;
	}

	/**
	 * Retrieve the File Resource
	 *
	 * @author Varun Shoor
	 * @return mixed "_fileResource" (RESOURCE) on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	protected function GetFileResource()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_fileResource;
	}

	/**
	 * Set the File Path
	 *
	 * @author Varun Shoor
	 * @param string $_filePath The File Path
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	protected function SetFilePath($_filePath)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (empty($_filePath)) {
			throw new SWIFT_Attachment_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$this->_filePath = $_filePath;

		return true;
	}

	/**
	 * Get the File Path
	 *
	 * @author Varun Shoor
	 * @return mixed "_filePath" (STRING) on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	public function GetFilePath()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_filePath;
	}

	/**
	 * Retrieve the File Chunk
	 *
	 * @author Varun Shoor
	 * @return mixed "_chunkData" (STRING) on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	public function GetChunk()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$_fileResource = $this->GetFileResource();
		if (!$_fileResource)
		{
			throw new SWIFT_Attachment_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_chunkData = fread($_fileResource, SWIFT_Attachment::GetChunkSize());
		if (strlen($_chunkData) == 0)
		{
			return false;
		}

		return $_chunkData;
	}
}
?>