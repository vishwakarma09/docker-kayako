<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The String Attachment Store Handling Class
 *
 * @author Varun Shoor
 */
class SWIFT_AttachmentStoreString extends SWIFT_AttachmentStore
{
	private $_chunkOffset = 0;

	/**
	 * @author Varun Shoor
	 *
	 * @param string $_fileName
	 * @param string $_fileType
	 * @param string $_dataContainer
	 * @param string $_contentID (OPTIONAL)
	 */
	public function __construct($_fileName, $_fileType, $_dataContainer, $_contentID = '')
	{
		/*
		 * BUG FIX - Rahul Bhattacharya
		 *
		 * SWIFT-3031 Incorrect handling of attachments created via REST API
		 *
		 */
		parent::__construct($_fileName, mb_strlen($_dataContainer, '8bit'), $_fileType, $_contentID);

		$this->SetData($_dataContainer);
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		parent::__destruct();

		return true;
	}

	/**
	 * Retrieve the Chunk
	 *
	 * @author Varun Shoor
	 * @return mixed "_chunkData" (STRING) on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	public function GetChunk()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$this->_maxChunkOffsetCount = ceil($this->GetFileSize()/SWIFT_Attachment::GetChunkSize());

		$_chunkProcessedOffset = $this->GetChunkOffset() * SWIFT_Attachment::GetChunkSize();

		if ($this->GetChunkOffset() > $this->_maxChunkOffsetCount)
		{
			return false;
		}

		$_chunkData = mb_substr($this->GetData(), $_chunkProcessedOffset, SWIFT_Attachment::GetChunkSize());

		$this->IncrementChunkOffset();

		return $_chunkData;
	}

	/**
	 * Set the Chunk Offset
	 *
	 * @author Varun Shoor
	 * @param int $_chunkOffset The Chunk Offset
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	protected function IncrementChunkOffset()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		$this->_chunkOffset++;

		return true;
	}

	/**
	 * Retrieve the Chunk Offset
	 *
	 * @author Varun Shoor
	 * @return mixed "_chunkOffset" (INT) on Success, "false" otherwise
	 * @throws SWIFT_Attachment_Exception If the Class is not Loaded
	 */
	protected function GetChunkOffset()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Attachment_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_chunkOffset;
	}
}
?>