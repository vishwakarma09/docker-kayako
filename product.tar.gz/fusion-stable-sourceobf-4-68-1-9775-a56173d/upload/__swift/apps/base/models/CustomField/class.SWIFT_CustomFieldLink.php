<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The Custom Field Link Management Class
 *
 * @author Varun Shoor
 */
class SWIFT_CustomFieldLink extends SWIFT_Model
{
	const TABLE_NAME		=	'customfieldlinks';
	const PRIMARY_KEY		=	'customfieldlinkid';

	const TABLE_STRUCTURE	=	"customfieldlinkid I PRIMARY AUTO NOTNULL,
								grouptype I2 DEFAULT '0' NOTNULL,
								linktypeid I DEFAULT '0' NOTNULL,
								customfieldgroupid I DEFAULT '0' NOTNULL";

	const INDEX_1			=	'grouptype, linktypeid, customfieldgroupid';
	const INDEX_2			=	'customfieldgroupid';


	protected $_dataStore = array();

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @param SWIFT_Data $_SWIFT_DataObject The SWIFT_Data Object
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Record could not be loaded
	 */
	public function __construct(SWIFT_Data $_SWIFT_DataObject)
	{
		parent::__construct();

		if (!$_SWIFT_DataObject instanceof SWIFT_Data || !$_SWIFT_DataObject->GetIsClassLoaded() || !$this->LoadData($_SWIFT_DataObject)) {
			throw new SWIFT_Exception('Failed to load Custom Field Link Object');

			$this->SetIsClassLoaded(false);

			return false;
		}

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		$this->ProcessUpdatePool();

		parent::__destruct();

		return true;
	}

	/**
	 * Processes the Update Pool Data
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function ProcessUpdatePool()
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		} else if (!_is_array($this->GetUpdatePool())) {
			return false;
		}

		$this->Database->AutoExecute(TABLE_PREFIX . 'customfieldlinks', $this->GetUpdatePool(), 'UPDATE', "customfieldlinkid = '" . intval($this->GetCustomFieldLinkID()) . "'");

		$this->ClearUpdatePool();

		return true;
	}

	/**
	 * Retrieves the Custom Field Link ID
	 *
	 * @author Varun Shoor
	 * @return mixed "customfieldlinkid" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetCustomFieldLinkID()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_dataStore['customfieldlinkid'];
	}

	/**
	 * Load the Data
	 *
	 * @author Varun Shoor
	 * @param SWIFT_Data $_SWIFT_DataObject The SWIFT_Data Object
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Ticket_Exception If Invalid Data is Provided
	 */
	protected function LoadData($_SWIFT_DataObject)
	{
		$_SWIFT = SWIFT::GetInstance();

		// Is it a ID?
		if ($_SWIFT_DataObject instanceof SWIFT_DataID && $_SWIFT_DataObject->GetIsClassLoaded())
		{
			$_dataStore = $_SWIFT->Database->QueryFetch("SELECT * FROM " . TABLE_PREFIX . "customfieldlinks WHERE customfieldlinkid = '" . intval($_SWIFT_DataObject->GetDataID()) . "'");
			if (isset($_dataStore['customfieldlinkid']) && !empty($_dataStore['customfieldlinkid']))
			{
				$this->_dataStore = $_dataStore;

				return true;
			}

			// Is it a Store?
		} else if ($_SWIFT_DataObject instanceof SWIFT_DataStore && $_SWIFT_DataObject->GetIsClassLoaded()) {
			$this->_dataStore = $_SWIFT_DataObject->GetDataStore();

			if (!isset($this->_dataStore['customfieldlinkid']) || empty($this->_dataStore['customfieldlinkid']))
			{
				throw new SWIFT_Exception(SWIFT_INVALIDDATA);
			}

			return true;
		}

		throw new SWIFT_Exception(SWIFT_INVALIDDATA);

		return false;
	}

	/**
	 * Returns the Data Store Array
	 *
	 * @author Varun Shoor
	 * @return mixed "_dataStore" Array on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetDataStore()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_dataStore;
	}

	/**
	 * Retrieves a Property Value from Data Store
	 *
	 * @author Varun Shoor
	 * @param string $_key The Key Identifier
	 * @return mixed Property Data on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetProperty($_key)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (!isset($this->_dataStore[$_key])) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		return $this->_dataStore[$_key];
	}

	/**
	 * Create a new Custom Field Link
	 *
	 * @author Varun Shoor
	 * @param constant $_groupType
	 * @param int $_linkTypeID
	 * @param int $_customFieldGroupID
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided or If the Object could not be created
	 */
	static public function Create($_groupType, $_linkTypeID, $_customFieldGroupID)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (empty($_linkTypeID) || !SWIFT_CustomFieldGroup::IsValidGroupType($_groupType) || empty($_customFieldGroupID))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_SWIFT->Database->Replace(TABLE_PREFIX . 'customfieldlinks', array('grouptype' => intval($_groupType), 'linktypeid' => intval($_linkTypeID),
			'customfieldgroupid' => intval($_customFieldGroupID)), array('grouptype', 'linktypeid', 'customfieldgroupid'));

		return true;
	}

	/**
	 * Delete the Custom Field Link record
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Delete()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		self::DeleteList(array($this->GetCustomFieldLinkID()));

		$this->SetIsClassLoaded(false);

		return true;
	}

	/**
	 * Delete a list of Custom Field Links
	 *
	 * @author Varun Shoor
	 * @param array $_customFieldLinkIDList
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function DeleteList($_customFieldLinkIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_customFieldLinkIDList))
		{
			return false;
		}

		$_SWIFT->Database->Query("DELETE FROM " . TABLE_PREFIX . "customfieldlinks WHERE customfieldlinkid IN (" . BuildIN($_customFieldLinkIDList) . ")");

		return true;
	}

	/**
	 * Delete the links and corresponding values based on group type and linktype id list
	 *
	 * @author Varun Shoor
	 * @param constant $_groupType The Group Type
	 * @param array $_linkTypeIDList The Link Type ID List
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function DeleteOnLink($_groupType, $_linkTypeIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!SWIFT_CustomFieldGroup::IsValidGroupType($_groupType))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);
		} else if (!_is_array($_linkTypeIDList)) {
			return false;
		}

		$_customFieldLinkIDList = array();
		$_SWIFT->Database->Query("SELECT customfieldlinkid FROM " . TABLE_PREFIX . "customfieldlinks
			WHERE grouptype = '" . intval($_groupType) . "' AND linktypeid IN (" . BuildIN($_linkTypeIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_customFieldLinkIDList[] = intval($_SWIFT->Database->Record['customfieldlinkid']);
		}

		if (!count($_customFieldLinkIDList))
		{
			return false;
		}

		self::DeleteList($_customFieldLinkIDList);

		return true;
	}

	/**
	 * Replace the links based on group type and link types
	 *
	 * @author Varun Shoor
	 * @param array $_groupTypeList
	 * @param array $_linkTypeIDList
	 * @param int $_newLinkTypeID
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function ReplaceOnLink($_groupTypeList, $_linkTypeIDList, $_newLinkTypeID) {
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_groupTypeList) || !_is_array($_linkTypeIDList) || empty($_newLinkTypeID)) {
			return false;
		}

		$_SWIFT->Database->AutoExecute(TABLE_PREFIX . 'customfieldlinks', array('linktypeid' => intval($_newLinkTypeID)), 'UPDATE', "grouptype IN (" . BuildIN($_groupTypeList) . ") AND linktypeid IN (" . BuildIN($_linkTypeIDList) . ")");

		return true;
	}

	/**
	 * Delete the Custom Field Links based on a list of Custom Field Group IDs
	 *
	 * @author Varun Shoor
	 * @param array $_customFieldGroupIDList The Custom Field Group ID List
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function DeleteOnCustomFieldGroup($_customFieldGroupIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_customFieldGroupIDList))
		{
			return false;
		}

		$_customFieldLinkIDList = array();
		$_SWIFT->Database->Query("SELECT customfieldlinkid FROM " . TABLE_PREFIX . "customfieldlinks WHERE customfieldgroupid IN (" . BuildIN($_customFieldGroupIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_customFieldLinkIDList[] = intval($_SWIFT->Database->Record['customfieldlinkid']);
		}

		if (!count($_customFieldLinkIDList))
		{
			return false;
		}

		self::DeleteList($_customFieldLinkIDList);

		return true;
	}
}
?>