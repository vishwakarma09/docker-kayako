<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The OnSite Session Management Class
 *
 * @author Varun Shoor
 */
class SWIFT_OnSiteSession extends SWIFT_Model
{
	const TABLE_NAME		=	'onsitesessions';
	const PRIMARY_KEY		=	'onsitesessionid';

	const TABLE_STRUCTURE	=	"onsitesessionid I PRIMARY AUTO NOTNULL,
								dateline I DEFAULT '0' NOTNULL,
								sessioncode C(5) DEFAULT '' NOTNULL,
								sessionhash C(60) DEFAULT '' NOTNULL,
								chatsessionid C(60) DEFAULT '' NOTNULL,
								chatobjectid I DEFAULT '0' NOTNULL,
								configid I2 DEFAULT '0' NOTNULL,
								peerjid C(100) DEFAULT '' NOTNULL,
								localjid C(100) DEFAULT '' NOTNULL,
								userid I DEFAULT '0' NOTNULL,
								staffname C(255) DEFAULT '' NOTNULL,
								staffid I DEFAULT '0' NOTNULL";

	const INDEX_1			=	'sessionhash, chatsessionid, chatobjectid';
	const INDEX_2			=	'dateline';
	const INDEX_3			=	'sessioncode';


	protected $_dataStore = array();

	const CLEANUP_THRESHOLD = 12; // In Hours
	const SESSION_EXPIRY = 3600; // In Seconds (1h)

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @param int $_onSiteSessionID The OnSite Session ID
	 * @param string $_chatSessionID (OPTIONAL) The Chat Session ID, if not false.. it should be valid
	 * @param string $_sessionHash (OPTIONAL) The Session Hash, if not false.. it should be valid
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Record could not be loaded
	 */
	public function __construct($_onSiteSessionID, $_chatSessionID = false, $_sessionHash = false)
	{
		parent::__construct();

		if (!$this->LoadData($_onSiteSessionID)) {
			throw new SWIFT_OnSite_Exception('Failed to load OnSite Session ID: ' . intval($_onSiteSessionID));

			$this->SetIsClassLoaded(false);

			return false;
		}

		if ($_chatSessionID && !$this->VerifyChatSessionID($_chatSessionID))
		{
			$this->SetIsClassLoaded(false);

			return false;
		}

		if ($_sessionHash && !$this->VerifySessionHash($_sessionHash))
		{
			$this->SetIsClassLoaded(false);

			return false;
		}

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		$this->ProcessUpdatePool();

		parent::__destruct();

		return true;
	}

	/**
	 * Processes the Update Pool Data
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded
	 */
	public function ProcessUpdatePool()
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		} else if (!_is_array($this->GetUpdatePool())) {
			return false;
		}

		$this->Database->AutoExecute(TABLE_PREFIX . 'onsitesessions', $this->GetUpdatePool(), 'UPDATE', "onsitesessionid = '" . intval($this->GetOnSiteSessionID()) . "'");

		$this->ClearUpdatePool();

		return true;
	}

	/**
	 * Retrieves the OnSite Session ID
	 *
	 * @author Varun Shoor
	 * @return mixed "onsitesessionid" on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded
	 */
	public function GetOnSiteSessionID()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_dataStore['onsitesessionid'];
	}

	/**
	 * Load the Data
	 *
	 * @author Varun Shoor
	 * @param int $_onSiteSessionID The OnSite Session ID
	 * @return bool "true" on Success, "false" otherwise
	 */
	protected function LoadData($_onSiteSessionID)
	{
		$_dataStore = $this->Database->QueryFetch("SELECT * FROM " . TABLE_PREFIX . "onsitesessions WHERE onsitesessionid = '" . intval($_onSiteSessionID) . "'");
		if (isset($_dataStore['onsitesessionid']) && !empty($_dataStore['onsitesessionid']))
		{
			$this->_dataStore = $_dataStore;

			return true;
		}

		return false;
	}

	/**
	 * Returns the Data Store Array
	 *
	 * @author Varun Shoor
	 * @return mixed "_dataStore" Array on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded
	 */
	public function GetDataStore()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_dataStore;
	}

	/**
	 * Retrieves a Property Value from Data Store
	 *
	 * @author Varun Shoor
	 * @param string $_key The Key Identifier
	 * @return mixed Property Data on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded
	 */
	public function GetProperty($_key)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (!isset($this->_dataStore[$_key])) {
			throw new SWIFT_OnSite_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		return $this->_dataStore[$_key];
	}

	/**
	 * Create a new OnSite Session
	 *
	 * @author Varun Shoor
	 * @param int $_configID The Server Configuration ID
	 * @param string $_peerJID The JID of the staff PC
	 * @param string $_localJID The JID of the customer PC
	 * @param string $_staffName The Name of staff starting this session
	 * @param int $_staffID The Staff ID starting this session
	 * @param int $_userID The User ID
	 * @param string $_chatSessionID The Chat Session ID
	 * @param int $_chatObjectID The Chat Object ID
	 * @return mixed "SWIFT_OnSiteSession" (OBJECT) on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If Invalid Data is Provided or If the Object could not be created
	 */
	static public function Create($_configID, $_peerJID, $_localJID, $_staffName, $_staffID, $_userID, $_chatSessionID = '', $_chatObjectID = false)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_chatObjectID = intval($_chatObjectID);

		$_onSiteSessionCode = sprintf('%1$04d', mt_rand(0, 9999));
		$_continueCheckingCode = true;

		do {
			$_onSiteSessionContainer = $_SWIFT->Database->QueryFetch("SELECT onsitesessionid FROM " . TABLE_PREFIX . "onsitesessions WHERE sessioncode = '" . $_SWIFT->Database->Escape($_onSiteSessionCode) . "'");

			if (!isset($_onSiteSessionContainer['onsitesessionid']) || empty($_onSiteSessionContainer['onsitesessionid'])) {
				$_continueCheckingCode = false;
			} else {
				$_onSiteSessionCode = sprintf('%1$04d', mt_rand(0, 9999));
			}

		} while ($_continueCheckingCode == true);

		$_onSiteSessionHash = BuildHash();
		$_SWIFT->Database->AutoExecute(TABLE_PREFIX . 'onsitesessions', array('dateline' => DATENOW, 'sessionhash' => $_onSiteSessionHash, 'chatsessionid' => $_chatSessionID, 'chatobjectid' => intval($_chatObjectID),
			'configid' => intval($_configID), 'peerjid' => $_peerJID, 'localjid' => $_localJID, 'staffname' => $_staffName, 'staffid' => intval($_staffID), 'sessioncode' => $_onSiteSessionCode, 'userid' => intval($_userID)), 'INSERT');
		$_onSiteSessionID = $_SWIFT->Database->Insert_ID();

		if (!$_onSiteSessionID)
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CREATEFAILED);

			return false;
		}

		return new SWIFT_OnSiteSession($_onSiteSessionID);
	}

	/**
	 * Update TABLENAME Record
	 *
	 * @author Varun Shoor
	 * @param string $_PARAM
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded or If Invalid Data is Provided
	 */
	public function Update()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return true;
	}

	/**
	 * Verify the Session Hash
	 *
	 * @author Varun Shoor
	 * @param string $_sessionHash The Session Hash
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded or If Invalid Data is Provided
	 */
	protected function VerifySessionHash($_sessionHash)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		if ($this->GetProperty('sessionhash') != $_sessionHash || empty($_sessionHash))
		{
			throw new SWIFT_OnSite_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		return true;
	}

	/**
	 * Verify the Chat Session ID
	 *
	 * @author Varun Shoor
	 * @param string $_chatSessionID The Chat Session ID
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded or If Invalid Data is Provided
	 */
	protected function VerifyChatSessionID($_chatSessionID)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		if ($this->GetProperty('chatsessionid') != $_chatSessionID || empty($_chatSessionID))
		{
			throw new SWIFT_OnSite_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		return true;
	}

	/**
	 * Delete the OnSite Session record
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_OnSite_Exception If the Class is not Loaded
	 */
	public function Delete()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_OnSite_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		self::DeleteList(array($this->GetOnSiteSessionID()));

		$this->SetIsClassLoaded(false);

		return true;
	}

	/**
	 * Delete a list of OnSite Session ID's
	 *
	 * @author Varun Shoor
	 * @param array $_onSiteSessionIDList The OnSite Session ID List
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function DeleteList($_onSiteSessionIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_onSiteSessionIDList))
		{
			return false;
		}

		$_finalOnSiteSessionIDList = array();
		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "onsitesessions WHERE onsitesessionid IN (" . BuildIN($_onSiteSessionIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_finalOnSiteSessionIDList[] = $_SWIFT->Database->Record['onsitesessionid'];
		}

		if (!count($_finalOnSiteSessionIDList))
		{
			return false;
		}

		$_SWIFT->Database->Query("DELETE FROM " . TABLE_PREFIX . "onsitesessions WHERE onsitesessionid IN (" . BuildIN($_finalOnSiteSessionIDList) . ")");

		return true;
	}

	/**
	 * Cleans up old OnSite Sessions
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function Cleanup()
	{
		$_SWIFT = SWIFT::GetInstance();

		$_dateThreshold = DATENOW - (self::CLEANUP_THRESHOLD * 3600);

		$_onSiteSessionIDList = array();
		$_SWIFT->Database->Query("SELECT onsitesessionid FROM " . TABLE_PREFIX . "onsitesessions
			WHERE dateline <= '" . intval($_dateThreshold) . "'");
		while ($_SWIFT->Database->NextRecord()) {
			$_onSiteSessionIDList[] = $_SWIFT->Database->Record['onsitesessionid'];
		}

		if (!count($_onSiteSessionIDList)) {
			return false;
		}

		self::DeleteList($_onSiteSessionIDList);

		return true;
	}

	/**
	 * Retrieve the OnSite Session Object on Code
	 *
	 * @author Varun Shoor
	 * @param string $_sessionCode
	 * @return SWIFT_OnSiteSession "Object" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function GetObjectOnCode($_sessionCode)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (empty($_sessionCode)) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);
		}

		$_onSiteSessionIDContainer = $_SWIFT->Database->QueryFetch("SELECT onsitesessionid FROM " . TABLE_PREFIX . "onsitesessions
			WHERE sessioncode = '" . $_SWIFT->Database->Escape($_sessionCode) . "'");

		if (!isset($_onSiteSessionIDContainer['onsitesessionid']) || empty($_onSiteSessionIDContainer['onsitesessionid'])) {
			return false;
		}

		return new SWIFT_OnSiteSession($_onSiteSessionIDContainer['onsitesessionid']);
	}
}
?>