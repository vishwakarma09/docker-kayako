<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * User > Email Management Class
 *
 * @author Varun Shoor
 */
class SWIFT_UserEmail extends SWIFT_UserEmailManager {
	static protected $_emailCache = array();

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @param int $_userEmailID The User Email ID
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	public function __construct($_userEmailID) {
		parent::__construct($_userEmailID);

		if ($this->GetProperty('linktype') != self::LINKTYPE_USER)
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct() {
		parent::__destruct();

		return true;
	}

	/**
	 * Create a new User Email Record
	 *
	 * @author Varun Shoor
	 * @param object $_SWIFT_UserObject The User Object
	 * @param string $_email The User Email
	 * @param bool $_isPrimary Whether the Email is Primary one for this user
	 * @return mixed "SWIFT_UserNote" Object on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided or If Creation Fails
	 */
	static public function Create(SWIFT_User $_SWIFT_UserObject, $_email, $_isPrimary = false) {
		if (!$_SWIFT_UserObject instanceof SWIFT_User || !$_SWIFT_UserObject->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_userEmailID = parent::Create(self::LINKTYPE_USER, $_SWIFT_UserObject->GetUserID(), $_email, $_isPrimary);
		if (!$_userEmailID) {
			throw new SWIFT_Exception(SWIFT_CREATEFAILED);

			return false;
		}

		self::$_emailCache = array();

		return new SWIFT_UserEmail($_userEmailID);
	}

	/**
	 * Delete the User Emails on the User ID List
	 *
	 * @author Varun Shoor
	 * @param array $_userIDList The User ID List
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function DeleteOnUser($_userIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userIDList))
		{
			return false;
		}

		$_userEmailIDList = array();
		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "useremails WHERE linktype = '" . self::LINKTYPE_USER . "' AND linktypeid IN (" . BuildIN($_userIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_userEmailIDList[] = $_SWIFT->Database->Record['useremailid'];
		}

		if (!count($_userEmailIDList))
		{
			return false;
		}

		self::$_emailCache = array();

		self::DeleteList($_userEmailIDList);

		return true;
	}

	/**
	 * Retrieve User ID based on User Email
	 *
	 * @author Varun Shoor
	 * @param array $_userEmail The User Email
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function RetrieveUserIDOnUserEmail($_userEmail)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (empty($_userEmail))
		{
			return false;
		}

		$_userEmailContainer = $_SWIFT->Database->QueryFetch("SELECT * FROM " . TABLE_PREFIX . "useremails WHERE linktype = '" . self::LINKTYPE_USER . "' AND email = '" . $_SWIFT->Database->Escape($_userEmail) . "'");
		if (isset($_userEmailContainer['linktypeid']) && !empty($_userEmailContainer['linktypeid']))
		{
			return $_userEmailContainer['linktypeid'];
		}

		return false;
	}

	/**
	 * Retrieve User ID List based on User Email ID List
	 *
	 * @author Varun Shoor
	 * @param array $_userEmailIDList The User Email ID List
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function RetrieveUserIDListOnUserEmail($_userEmailIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userEmailIDList))
		{
			return false;
		}

		$_userIDList = array();
		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "useremails WHERE linktype = '" . self::LINKTYPE_USER . "' AND useremailid IN (" . BuildIN($_userEmailIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_userIDList[] = $_SWIFT->Database->Record['linktypeid'];
		}

		if (!count($_userIDList))
		{
			return false;
		}

		return $_userIDList;
	}

	/**
	 * Check to see if a given email already exists.. if it does, return the relevant user id
	 *
	 * @author Varun Shoor
	 * @param array $_emailList The Email List
	 * @param int $_currentUserID (OPTIONAL) The Current User ID to ignore
	 * @return mixed array(email, linktypeid) on Success, "false" otherwise
	 */
	static public function CheckEmailRecordExists($_emailList, $_currentUserID = false)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_emailList))
		{
			return false;
		}

		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "useremails WHERE linktype = '" . self::LINKTYPE_USER . "' AND email IN (" . BuildIN($_emailList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			if (!empty($_currentUserID) && $_SWIFT->Database->Record['linktypeid'] == $_currentUserID)
			{
				// Belongs to the current user ignore...
			} else {
				return array($_SWIFT->Database->Record['email'], $_SWIFT->Database->Record['linktypeid']);
			}
		}

		return false;
	}

	/**
	 * Retrieve all emails for the given user id
	 *
	 * @author Varun Shoor
	 * @param int $_userID The User ID
	 * @param bool $_tagID (OPTIONAL) Whether to tag the useremailid
	 * @return mixed "_emailList" (ARRAY) on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveList($_userID, $_tagID = false)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_userID = intval($_userID);
		if (empty($_userID))
		{
			return array();
		}

		$_cacheKey = $_userID . '-' . $_tagID;
		if (isset(self::$_emailCache[$_cacheKey]))
		{
			return self::$_emailCache[$_cacheKey];
		}

		$_emailList = array();

		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "useremails WHERE linktype = '" . self::LINKTYPE_USER . "' AND linktypeid = '" . intval($_userID) . "' ORDER BY useremailid ASC");
		while ($_SWIFT->Database->NextRecord())
		{
			if ($_tagID)
			{
				$_emailList[$_SWIFT->Database->Record['useremailid']] = $_SWIFT->Database->Record['email'];
			} else {
				$_emailList[] = $_SWIFT->Database->Record['email'];
			}
		}

		self::$_emailCache[$_cacheKey] = $_emailList;

		return $_emailList;
	}

	/**
	 * Retrieve a list of emails based on a list of users
	 *
	 * @author Varun Shoor
	 * @param array $_userIDList The User ID List
	 * @return array The User Email List
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveListOnUserIDList($_userIDList) {
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userIDList)) {
			return array();
		}

		$_emailList = array();
		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "useremails WHERE linktype = '" . self::LINKTYPE_USER . "' AND linktypeid IN (" . BuildIN($_userIDList) . ") ORDER BY useremailid ASC");
		while ($_SWIFT->Database->NextRecord()) {
			if (!in_array($_SWIFT->Database->Record['email'], $_emailList)) {
				$_emailList[] = $_SWIFT->Database->Record['email'];
			}
		}

		return $_emailList;
	}

	/**
	 * Retrieve User Email ID from a User ID
	 *
	 * @author Varun Shoor
	 * @param int $_userID The User ID
	 * @return mixed "useremailid" (INT) on Success, "false" otherwise
	 */
	static public function RetrieveUserEmailID($_userID)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_userID = intval($_userID);
		if (empty($_userID))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_userEmailContainer = $_SWIFT->Database->QueryFetch("SELECT * FROM " . TABLE_PREFIX . "useremails WHERE linktype = '" . self::LINKTYPE_USER . "' AND linktypeid = '" . intval($_userID) . "'");
		if (isset($_userEmailContainer['useremailid']) && !empty($_userEmailContainer['useremailid']))
		{
			return $_userEmailContainer['useremailid'];
		}

		return false;
	}

	/**
	 * Retrieve primary email for the given user id
	 *
	 * @author Bishwanath Jha
	 *
	 * @param int  $_userID The User ID
	 * @param bool $_tagID  (OPTIONAL) Whether to tag the useremailid
	 *
	 * @throws SWIFT_Exception If no userid is provided
	 * @return mixed "_email" (STRING) on Success, "false" otherwise
	 */
	static public function GetPrimaryEmail($_userID, $_tagID = false)
	{
		$_userID = intval($_userID);

		if (empty($_userID)) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);
		}

		$_emailList = SWIFT_UserEmail::RetrieveList($_userID, $_tagID);

		if (empty($_emailList)) {
			return array();
		}

		return $_emailList[0];
	}
}
?>