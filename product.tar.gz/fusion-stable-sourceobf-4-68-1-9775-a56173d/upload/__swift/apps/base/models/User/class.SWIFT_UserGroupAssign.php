<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * User Group Assignment Class
 *
 * @author Varun Shoor
 */
class SWIFT_UserGroupAssign extends SWIFT_Model {
	const TABLE_NAME		=	'usergroupassigns';
	const PRIMARY_KEY		=	'usergroupassignid';

	const TABLE_STRUCTURE	=	"usergroupassignid I PRIMARY AUTO NOTNULL,
								toassignid I DEFAULT '0' NOTNULL,
								type I2 DEFAULT '0' NOTNULL,
								usergroupid I DEFAULT '0' NOTNULL";

	const INDEX_1			=	'usergroupid, type';
	const INDEX_2			=	'toassignid, type, usergroupid';


	// Core Constants
	const TYPE_DEPARTMENT = 1;
	const TYPE_TICKETPRIORITY = 2;
	const TYPE_WIDGET = 3;
	const TYPE_RATING = 4;
	const TYPE_TICKETTYPE = 5;
	const TYPE_NEWS = 6;
	const TYPE_KBCATEGORY = 7;
	const TYPE_TROUBLESHOOTERCATEGORY = 9;

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __construct() {
		parent::__construct();

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct() {
		parent::__destruct();

		return true;
	}

	/**
	 * Insert a new User Group Assignment Record
	 *
	 * @author Varun Shoor
	 * @param int $_toAssignID The To Assignment ID
	 * @param int $_type The User Group Assignment Type
	 * @param int $_userGroupID The User Group ID
	 * @param bool $_rebuildCache Whether the rebuild cache should be done automatically
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function Insert($_toAssignID, $_type, $_userGroupID, $_rebuildCache = true) {
		$_SWIFT = SWIFT::GetInstance();

		$_toAssignID = intval($_toAssignID);

		if (!self::IsValidType($_type) || empty($_toAssignID)) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_SWIFT->Database->AutoExecute(TABLE_PREFIX .'usergroupassigns', array('toassignid' => intval($_toAssignID), 'type' => intval($_type), 'usergroupid' => intval($_userGroupID)), 'INSERT');

		if ($_rebuildCache)
		{
			self::RebuildCache();
		}

		return true;
	}

	/**
	 * Checks to see if it is a valid user group assignment type
	 *
	 * @author Varun Shoor
	 * @param int $_type The Assignment Type
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function IsValidType($_type) {
		if ($_type == self::TYPE_DEPARTMENT || $_type == self::TYPE_TICKETPRIORITY || $_type == self::TYPE_WIDGET ||
				$_type == self::TYPE_RATING || $_type == self::TYPE_TICKETTYPE || $_type == self::TYPE_NEWS || $_type == self::TYPE_KBCATEGORY ||
				$_type == self::TYPE_TROUBLESHOOTERCATEGORY) {
			return true;
		}

		return false;
	}

	/**
	 * Deletes the User Group Assignment List
	 *
	 * @author Varun Shoor
	 * @param array $_toAssignIDList The ID Container List
	 * @param int $_type The Assignment Type
	 * @param bool $_rebuildCache Whether the rebuild cache should be done automatically
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function DeleteList($_toAssignIDList, $_type, $_rebuildCache = true) {
		$_SWIFT = SWIFT::GetInstance();

		if (!self::IsValidType($_type)) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_SWIFT->Database->Query("DELETE FROM ". TABLE_PREFIX ."usergroupassigns WHERE toassignid IN (". BuildIN($_toAssignIDList) .") AND type = '". intval($_type) ."'");

		if ($_rebuildCache)
		{
			self::RebuildCache();
		}

		return true;
	}

	/**
	 * Delete Based on User Group ID List
	 *
	 * @author Varun Shoor
	 * @param array $_userGroupIDList The User Group ID List
	 * @param bool $_rebuildCache Whether the rebuild cache should be done automatically
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function DeleteListUserGroupID($_userGroupIDList, $_rebuildCache = true) {
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userGroupIDList)) {
			return false;
		}

		$_SWIFT->Database->Query("DELETE FROM ". TABLE_PREFIX ."usergroupassigns WHERE usergroupid IN (". BuildIN($_userGroupIDList) .")");

		if ($_rebuildCache)
		{
			self::RebuildCache();
		}

		return true;
	}

	/**
	 * Rebuilds the User Group Assignment Cache
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function RebuildCache() {
		$_SWIFT = SWIFT::GetInstance();

		$_cache = array();

		$_SWIFT->Database->Query("SELECT * FROM ". TABLE_PREFIX ."usergroupassigns", 3);
		while ($_SWIFT->Database->NextRecord(3))
		{
			$_cache[$_SWIFT->Database->Record3['type']][$_SWIFT->Database->Record3['usergroupid']][] = $_SWIFT->Database->Record3['toassignid'];
		}

		$_SWIFT->Cache->Update('usergroupassigncache', $_cache);

		return true;
	}

	/**
	 * Retrieve the User Group List
	 *
	 * @author Varun Shoor
	 * @param int $_toAssignID The ID to which user group list is assigned to
	 * @param int $_type The Assign Type
	 * @return mixed "userGroupIDList" Array on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function Retrieve($_toAssignID, $_type) {
		$_SWIFT = SWIFT::GetInstance();

		$_toAssignID = intval($_toAssignID);

		if (!self::IsValidType($_type) || empty($_toAssignID)) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_userGroupIDList = array();
		$_SWIFT->Database->Query("SELECT * FROM ". TABLE_PREFIX ."usergroupassigns WHERE toassignid = '". intval($_toAssignID) ."' AND type = '". intval($_type) ."'");
		while ($_SWIFT->Database->NextRecord())
		{
			$_userGroupIDList[$_SWIFT->Database->Record['usergroupid']] = '1';
		}

		return $_userGroupIDList;
	}

	/**
	 * Retrieve a list of User Group ID's linked to a given type
	 *
	 * @author Varun Shoor
	 * @param constant $_linkType The Link Type
	 * @param int $_toAssignID The Link'ed Object's ID
	 * @return mixed "_userGroupIDList" (ARRAY) on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveList($_linkType, $_toAssignID)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_toAssignID = intval($_toAssignID);

		if (empty($_toAssignID) || !self::IsValidType($_linkType))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_userGroupIDList = array();

		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "usergroupassigns WHERE toassignid = '" . intval($_toAssignID) . "' AND type = '" . intval($_linkType) . "'");
		while ($_SWIFT->Database->NextRecord())
		{
			$_userGroupIDList[] = $_SWIFT->Database->Record['usergroupid'];
		}

		return $_userGroupIDList;
	}

	/**
	 * Retrieve a map of User Group ID's linked to a given type and specified ids
	 *
	 * @author Varun Shoor
	 * @param constant $_linkType The Link Type
	 * @param array $_toAssignIDList The Link'ed Object's IDs
	 * @return mixed "_userGroupIDMap" (ARRAY) on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveMap($_linkType, $_toAssignIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!self::IsValidType($_linkType))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		} else if (!_is_array($_toAssignIDList)) {
			return false;
		}

		$_userGroupIDMap = array();

		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "usergroupassigns WHERE toassignid IN (" . BuildIN($_toAssignIDList) .
				") AND type = '" . intval($_linkType) . "'");
		while ($_SWIFT->Database->NextRecord())
		{
			$_userGroupIDMap[$_SWIFT->Database->Record['toassignid']][] = $_SWIFT->Database->Record['usergroupid'];
		}

		return $_userGroupIDMap;
	}

	/**
	 * Retrieve a list of assigned ids based on a user group id
	 *
	 * @author Varun Shoor
	 * @param int $_userGroupID The User Group ID
	 * @param constant $_linkType The Link Type
	 * @return array The Assign List
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveListOnUserGroup($_userGroupID, $_linkType)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_userGroupID = intval($_userGroupID);

		if (empty($_userGroupID) || !self::IsValidType($_linkType))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_userGroupAssignCache = $_SWIFT->Cache->Get('usergroupassigncache');

		// No type container?
		if (!isset($_userGroupAssignCache[$_linkType]) ||
				!isset($_userGroupAssignCache[$_linkType][$_userGroupID]) ||
				!_is_array($_userGroupAssignCache[$_linkType][$_userGroupID]))
		{
			return array();
		}

		return $_userGroupAssignCache[$_linkType][$_userGroupID];
	}

	/**
	 * Check to see if the item is linked to the given user group..
	 *
	 * @author Varun Shoor
	 * @param constant $_linkType The Link Type
	 * @param int $_toAssignID The Link'ed Object's ID
	 * @param int $_userGroupID The User Group ID
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function IsItemLinkedToUserGroup($_linkType, $_toAssignID, $_userGroupID)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_toAssignID = intval($_toAssignID);

		if (empty($_toAssignID) || !self::IsValidType($_linkType))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_userGroupAssignCache = $_SWIFT->Cache->Get('usergroupassigncache');

		// No type container?
		if (!isset($_userGroupAssignCache[$_linkType]) || !isset($_userGroupAssignCache[$_linkType][$_userGroupID]) || !_is_array($_userGroupAssignCache[$_linkType][$_userGroupID]))
		{
			return false;
		}

		// Is this item linked to the user group?
		if (in_array($_toAssignID, $_userGroupAssignCache[$_linkType][$_userGroupID]))
		{
			return true;
		}

		return false;
	}
}
?>