<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * Organization Note Management Class
 *
 * @author Varun Shoor
 */
class SWIFT_UserOrganizationNote extends SWIFT_UserNoteManager {
	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @param int $_userNoteID The User Note ID
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __construct($_userNoteID) {
		return parent::__construct($_userNoteID);
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct() {
		parent::__destruct();

		return true;
	}

	/**
	 * Create a new Organization Note
	 *
	 * @author Varun Shoor
	 * @param object $_SWIFT_UserOrganizationObject The User Organization Object
	 * @param string $_noteContents The Note Contents
	 * @param int $_noteColor The Note Color
	 * @return mixed "SWIFT_UserNote" Object on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided or If Creation Fails
	 */
	static public function Create(SWIFT_UserOrganization $_SWIFT_UserOrganizationObject, $_noteContents, $_noteColor = 1) {
		$_SWIFT = SWIFT::GetInstance();

		if (!$_SWIFT_UserOrganizationObject instanceof SWIFT_UserOrganization || !$_SWIFT_UserOrganizationObject->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		} else if (!$_SWIFT->Staff instanceof SWIFT_Staff || !$_SWIFT->Staff->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_userNoteID = parent::Create(self::LINKTYPE_ORGANIZATION, $_SWIFT_UserOrganizationObject->GetUserOrganizationID(), $_SWIFT->Staff->GetStaffID(), $_SWIFT->Staff->GetProperty('fullname'), $_noteContents, $_noteColor);
		if (!$_userNoteID) {
			throw new SWIFT_Exception(SWIFT_CREATEFAILED);

			return false;
		}

		return new SWIFT_UserOrganizationNote($_userNoteID);
	}

	/**
	 * Delete User Notes based on User Organization ID List
	 *
	 * @author Varun Shoor
	 * @param array $_userOrganizationIDList The User Organization ID List
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function DeleteOnUserOrganization($_userOrganizationIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userOrganizationIDList))
		{
			return false;
		}

		$_userNoteIDList = array();
		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "usernotes WHERE linktype = '" . self::LINKTYPE_ORGANIZATION . "' AND linktypeid IN (" . BuildIN($_userOrganizationIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_userNoteIDList[] = $_SWIFT->Database->Record['usernoteid'];
		}

		if (!count($_userNoteIDList))
		{
			return false;
		}

		self::DeleteList($_userNoteIDList);

		return true;
	}
}
?>