<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The User Profile Image Manager
 *
 * @author Varun Shoor
 */
class SWIFT_UserProfileImage extends SWIFT_Model
{
	const TABLE_NAME		=	'userprofileimages';
	const PRIMARY_KEY		=	'userprofileimageid';

	const TABLE_STRUCTURE	=	"userprofileimageid I PRIMARY AUTO NOTNULL,
								dateline I DEFAULT '0' NOTNULL,
								userid I DEFAULT '0' NOTNULL,
								extension C(255) DEFAULT '' NOTNULL,
								imagedata X2";

	const INDEX_1			=	'userid';


	protected $_dataStore = array();

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @param SWIFT_Data $_SWIFT_DataObject The SWIFT_Data Object
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Record could not be loaded
	 */
	public function __construct(SWIFT_Data $_SWIFT_DataObject)
	{
		parent::__construct();

		if (!$_SWIFT_DataObject instanceof SWIFT_Data || !$_SWIFT_DataObject->GetIsClassLoaded() || !$this->LoadData($_SWIFT_DataObject)) {
			throw new SWIFT_Exception('Failed to load User Profile Image Object');

			$this->SetIsClassLoaded(false);

			return false;
		}

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		$this->ProcessUpdatePool();

		parent::__destruct();

		return true;
	}

	/**
	 * Processes the Update Pool Data
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function ProcessUpdatePool()
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		} else if (!_is_array($this->GetUpdatePool())) {
			return false;
		}

		$this->Database->AutoExecute(TABLE_PREFIX . 'userprofileimages', $this->GetUpdatePool(), 'UPDATE', "userprofileimageid = '" .
				intval($this->GetUserProfileImageID()) . "'");

		$this->ClearUpdatePool();

		return true;
	}

	/**
	 * Retrieves the User Profile Image ID
	 *
	 * @author Varun Shoor
	 * @return mixed "userprofileimageid" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetUserProfileImageID()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_dataStore['userprofileimageid'];
	}

	/**
	 * Load the Data
	 *
	 * @author Varun Shoor
	 * @param SWIFT_Data $_SWIFT_DataObject The SWIFT_Data Object
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	protected function LoadData($_SWIFT_DataObject)
	{
		// Is it a ID?
		if ($_SWIFT_DataObject instanceof SWIFT_DataID && $_SWIFT_DataObject->GetIsClassLoaded())
		{
			$_dataStore = $this->Database->QueryFetch("SELECT * FROM " . TABLE_PREFIX . "userprofileimages WHERE userprofileimageid = '" .
					intval($_SWIFT_DataObject->GetDataID()) . "'");
			if (isset($_dataStore['userprofileimageid']) && !empty($_dataStore['userprofileimageid']))
			{
				$this->_dataStore = $_dataStore;

				return true;
			}

		// Is it a Store?
		} else if ($_SWIFT_DataObject instanceof SWIFT_DataStore && $_SWIFT_DataObject->GetIsClassLoaded()) {
			$this->_dataStore = $_SWIFT_DataObject->GetDataStore();

			if (!isset($this->_dataStore['userprofileimageid']) || empty($this->_dataStore['userprofileimageid']))
			{
				throw new SWIFT_Exception(SWIFT_INVALIDDATA);
			}

			return true;
		}

		throw new SWIFT_Exception(SWIFT_INVALIDDATA);

		return false;
	}

	/**
	 * Returns the Data Store Array
	 *
	 * @author Varun Shoor
	 * @return mixed "_dataStore" Array on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetDataStore()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		return $this->_dataStore;
	}

	/**
	 * Retrieves a Property Value from Data Store
	 *
	 * @author Varun Shoor
	 * @param string $_key The Key Identifier
	 * @return mixed Property Data on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetProperty($_key)
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		} else if (!isset($this->_dataStore[$_key])) {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		return $this->_dataStore[$_key];
	}

	/**
	 * Retrieve the Profile Images based on given User ID's
	 *
	 * @author Varun Shoor
	 * @param array $_userIDList The User ID List
	 * @return mixed "_profileImageContainer" (ARRAY) on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveList($_userIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userIDList)) {
			return false;
		}

		$_profileImageContainer = array();
		$_SWIFT->Database->Query("SELECT * FROM " . TABLE_PREFIX . "userprofileimages WHERE userid IN (" . BuildIN($_userIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_profileImageContainer[$_SWIFT->Database->Record['userid']] = $_SWIFT->Database->Record['imagedata'];
		}

		return $_profileImageContainer;
	}

	/**
	 * Check to see if there is a Profile Object data on User ID
	 *
	 * @author Varun Shoor
	 * @param int $_userID The User ID
	 * @return mixed "SWIFT_UserProfileImage" (OBJECT) on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function UserHasProfileImage($_userID)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_userProfileImageContainer = $_SWIFT->Database->QueryFetch("SELECT userprofileimageid FROM " . TABLE_PREFIX . "userprofileimages WHERE userid = '" . intval($_userID) . "'");
		if ($_userProfileImageContainer && isset($_userProfileImageContainer['userprofileimageid']) && !empty($_userProfileImageContainer['userprofileimageid']))
		{
			return true;
		}

		return false;
	}

	/**
	 * Retrieve the Profile Object data on User ID
	 *
	 * @author Varun Shoor
	 * @param int $_userID The User ID
	 * @return mixed "SWIFT_UserProfileImage" (OBJECT) on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveOnUser($_userID)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_userProfileImageContainer = $_SWIFT->Database->QueryFetch("SELECT userprofileimageid FROM " . TABLE_PREFIX .
				"userprofileimages WHERE userid = '" . intval($_userID) . "'");
		if ($_userProfileImageContainer && isset($_userProfileImageContainer['userprofileimageid']) && !empty($_userProfileImageContainer['userprofileimageid']))
		{
			return new SWIFT_UserProfileImage(new SWIFT_DataID($_userProfileImageContainer['userprofileimageid']));
		}

		return false;
	}

	/**
	 * Retrieve on basis of user id list
	 *
	 * @author Varun Shoor
	 * @param array $_userIDList The User ID List
	 * @return array $_userProfileImageObjectContainer
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function RetrieveOnUserList($_userIDList) {
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userIDList)) {
			return false;
		}

		$_userProfileImageObjectContainer = array();

		$_SWIFT->Database->Query("SELECT userid, userprofileimageid FROM " . TABLE_PREFIX . "userprofileimages WHERE userid IN (" . BuildIN($_userIDList) . ")");
		while ($_SWIFT->Database->NextRecord()) {
			$_userProfileImageObjectContainer[$_SWIFT->Database->Record['userid']] = $_SWIFT->Database->Record['userprofileimageid'];
		}

		return $_userProfileImageObjectContainer;
	}

	/**
	 * Output the Image
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Output()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		HeaderNoCache();

		switch ($this->GetProperty('extension'))
		{
			case 'png':
				header('Content-type: image/png');

				echo base64_decode($this->GetProperty('imagedata'));

				break;

			case 'gif';
				header('Content-type: image/gif');

				echo base64_decode($this->GetProperty('imagedata'));

				break;

			case 'jpeg';
			case 'jpg';
				header('Content-type: image/jpeg');

				echo base64_decode($this->GetProperty('imagedata'));

				break;

			default:
				throw new SWIFT_Exception(SWIFT_INVALIDDATA);
				break;
		}

		return true;
	}

	/**
	 * Create a new User Profile Image
	 *
	 * @author Varun Shoor
	 * @param int $_userID The User ID
	 * @param strin $_imageExtension The Image Extension
	 * @param string $_imageData The Base64 Encoded Image Data
	 * @return mixed "_userProfileImageID" (INT) on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided or If the Object could not be created
	 */
	static public function Create($_userID, $_imageExtension, $_imageData)
	{
		$_SWIFT = SWIFT::GetInstance();

		$_userID = intval($_userID);

		if (empty($_userID) || empty($_imageData) || empty($_imageExtension))
		{
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);

			return false;
		}

		$_SWIFT->Database->AutoExecute(TABLE_PREFIX . 'userprofileimages', array('userid' => intval($_userID), 'extension' => strtolower($_imageExtension), 'imagedata' => $_imageData, 'dateline' => DATENOW), 'INSERT');
		$_userProfileImageID = $_SWIFT->Database->Insert_ID();

		if (!$_userProfileImageID)
		{
			throw new SWIFT_Exception(SWIFT_CREATEFAILED);

			return false;
		}

		return $_userProfileImageID;
	}

	/**
	 * Delete the User Profile Image record
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Delete()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		self::DeleteList(array($this->GetUserProfileImageID()));

		$this->SetIsClassLoaded(false);

		return true;
	}

	/**
	 * Delete a list of User Profile Images
	 *
	 * @author Varun Shoor
	 * @param array $_userProfileImageIDList The User Profile Image ID Container Array
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function DeleteList($_userProfileImageIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userProfileImageIDList))
		{
			return false;
		}

		$_finalUserProfileImageIDList = array();

		$_SWIFT->Database->Query("SELECT userprofileimageid FROM " . TABLE_PREFIX . "userprofileimages WHERE userprofileimageid IN (" . BuildIN($_userProfileImageIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_finalUserProfileImageIDList[] = $_SWIFT->Database->Record['userprofileimageid'];
		}

		if (!count($_finalUserProfileImageIDList))
		{
			return false;
		}

		$_SWIFT->Database->Query("DELETE FROM " . TABLE_PREFIX . "userprofileimages WHERE userprofileimageid IN (" . BuildIN($_finalUserProfileImageIDList) . ")");

		return true;
	}

	/**
	 * Delete the User Profile Images based on User ID's
	 *
	 * @author Varun Shoor
	 * @param array $_userIDList The User ID List
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function DeleteOnUser($_userIDList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_userIDList))
		{
			return false;
		}

		$_userProfileImageIDList = array();

		$_SWIFT->Database->Query("SELECT userprofileimageid FROM " . TABLE_PREFIX . "userprofileimages WHERE userid IN (" . BuildIN($_userIDList) . ")");
		while ($_SWIFT->Database->NextRecord())
		{
			$_userProfileImageIDList[] = $_SWIFT->Database->Record['userprofileimageid'];
		}

		if (!count($_userProfileImageIDList))
		{
			return false;
		}

		self::DeleteList($_userProfileImageIDList);

		return true;
	}
}
?>