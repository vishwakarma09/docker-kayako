<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The Cron Daily Controller
 *
 * @author Varun Shoor
 */
class Controller_Daily extends Controller_cron
{
	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __construct()
	{
		parent::__construct();

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		parent::__destruct();

		return true;
	}

	/**
	 * The Daily Cleanup
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Cleanup()
	{
		if (!$this->GetIsClassLoaded())
		{
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);

			return false;
		}

		// Cleanup File Logs
		SWIFT_Log::CleanUp();

		if (SWIFT_App::IsInstalled(APP_BASE)) {
			$_activeStaffCount = 0;
			$_activeStaffCountContainer = $this->Database->QueryFetch("SELECT COUNT(*) AS totalitems FROM " . TABLE_PREFIX . "staff WHERE isenabled = '1'");
			if (isset($_activeStaffCountContainer['totalitems']))
			{
				$_activeStaffCount = $_activeStaffCountContainer['totalitems'];
			}

			$_context = stream_context_create(array(
				'http' => array(
					'timeout' => 10
					)
				)
			);

			$_result = @file_get_contents(base64_decode('aHR0cHM6Ly9teS5rYXlha28uY29tL0JhY2tlbmQvTGljZW5zZS9JbmRleC8=') . base64_encode('d=' . SWIFT::Get('basename') . '&c=' . intval($_activeStaffCount) . '&v=' . SWIFT_VERSION), 0, $_context);
		}

		return true;
	}

	/**
	 * The Default Daily Method
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Index()
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		}

		SWIFT_CronManager::RunModelCron(SWIFT_CronManager::TYPE_DAILY);

		$this->Cleanup();

		return true;
	}
}
?>
