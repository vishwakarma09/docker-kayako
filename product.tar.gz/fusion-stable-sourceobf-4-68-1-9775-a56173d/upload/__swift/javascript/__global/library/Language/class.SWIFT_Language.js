SWIFT.Library.Language = SWIFT.Base.extend({

});