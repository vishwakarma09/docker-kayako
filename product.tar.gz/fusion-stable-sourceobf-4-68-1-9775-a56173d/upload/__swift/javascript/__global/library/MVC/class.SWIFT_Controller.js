SWIFT.Library.Controller = SWIFT.Base.extend({
});