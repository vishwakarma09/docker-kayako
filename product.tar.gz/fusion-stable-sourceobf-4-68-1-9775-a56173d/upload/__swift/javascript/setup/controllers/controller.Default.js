SWIFT.Controller('core', 'default', SWIFT.Base.create({
	index: function() {
	}
}));